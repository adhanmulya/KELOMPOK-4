/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rplddi;

/**
 *
 * @author Mikogizka
 */
public class RPLDDI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame1 f1 = new  Frame1();
        f1.setVisible(true);
        f1.pack();
        f1.setLocationRelativeTo(null);
        f1.setDefaultCloseOperation(Frame1.EXIT_ON_CLOSE);
    }
    
}
