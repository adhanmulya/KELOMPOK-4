/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassCode;
import java.time.LocalDate;
/**
 *
 * @author Mikogizka
 */
public class Guest {
    public String nama, jenisKelamin, alamat, obat;
    public LocalDate tglLahir;
    
    public void Guest(String nama, String jenisKelamin, String alamat, String obat, LocalDate tglLahir){
        getNama();
        getJK();
        getAlamat();
        getObat();
        getTglLahir();
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public void setJK(String jenisKelamin){
        this.jenisKelamin = jenisKelamin;
    }
    public void setAlamat(String alamat){
        this.alamat = alamat;
    }
    public void setObat(String obat){
        this.obat = obat;
    }
    public void setTglLahir(LocalDate tglLahir){
        this.tglLahir = tglLahir;
    }
    
    public String getNama(){
        return nama;
    }
    public String getJK(){
        return jenisKelamin;
    }
    public String getAlamat(){
        return alamat;
    }
    public String getObat(){
        return obat;
    }
    public LocalDate getTglLahir(){
        return tglLahir;
    }
    
    public void cariObat(){
    
    }
}
