/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassCode;

import java.time.LocalDate;

/**
 *
 * @author Mikogizka
 */
public class Buyer extends Guest {
    private int wallet;
    
    public void Buyer(String nama, String jenisKelamin, String alamat, String obat, LocalDate tglLahir, int wallet){
        this.wallet = wallet;
    }
    public void setWallet(int wallet){
        this.wallet = wallet;
    }
    public int getWallet(){
        return wallet;
    }
    
    public void tambahKeranjang(){
    }
    public void Beli(){
    }
    
}
