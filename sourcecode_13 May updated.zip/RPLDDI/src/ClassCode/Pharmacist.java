/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassCode;

/**
 *
 * @author Mikogizka
 */
public class Pharmacist {
    public String namaPhar, emailPhar;

    Pharmacist(String namaPhar, String emailPhar){
       this.namaPhar = namaPhar;
       this.emailPhar = emailPhar;
    }
    public void setNamaPhar(String namaPhar){
        this.namaPhar = namaPhar;
    }
    public void setEmail(String emailPhar){
        this.emailPhar = emailPhar;
    }
    
    public String getNamaPhar(){
        return namaPhar;
    }
    public String getEmail(){
        return emailPhar;
    }

}
