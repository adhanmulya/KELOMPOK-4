/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassCode;
import java.time.LocalDate;
import java.util.LinkedList;
/**
 *
 * @author Mikogizka
 */
public class Patient extends Guest {
    private int usia, beratBadan;
    private String keluhan;
    private LinkedList<Pharmacist>Phar;
    
    public void Patient(String nama, String jenisKelamin, String alamat, String obat, LocalDate tglLahir, int usia, int beratBadan, String keluhan){
        this.usia = usia;
        this.beratBadan = beratBadan;
        this.keluhan = keluhan;
        Phar = new LinkedList<Pharmacist>();
    }
    public void setUsia(int usia){
        this.usia = usia;
    }
    public void setBB(int beratBadan){
        this.beratBadan = beratBadan;
    }
    public void setKeluhan(String keluhan){
        this.keluhan = keluhan;
    }
    
    public int getUsia(){
        return usia;
    }
    public int getBB(){
        return beratBadan;
    }
    public String getKeluhan(){
        return keluhan;
    }
    
    public void consRequest(){
    }
    public void consInfo(){
    }
    public void pharInfo(String namaPhar, String emailPhar){
        Pharmacist pharPatient = new Pharmacist(namaPhar, emailPhar);
        System.out.println("Nama Pharmacist: "+namaPhar);
        System.out.println("Email Pharmacist: "+emailPhar);
    }
}
